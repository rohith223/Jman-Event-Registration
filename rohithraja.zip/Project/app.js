const express = require('express')
const app = express()
const bodyParser = require("body-parser");
const fileUpload = require('express-fileupload')
const path = require('path')
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
const port = 3002

const cors = require('cors');

app.use(cors({
  origin: '*'
}));

app.set('view engine', 'ejs');
// app.use('/public', express.static('public'));
// app.use(express.static(__dirname + '/public'));

// app.use(fileUpload())
// app.use(express.static('public'))
const nodemailer = require('nodemailer');

// const transporter = nodemailer.createTransport({
//     service: 'gmail',
//     auth: {
//       type: 'OAuth2',
//       user: secure_configuration.EMAIL_USERNAME,
//       pass: secure_configuration.PASSWORD,
//       clientId: secure_configuration.CLIENT_ID,
//       clientSecret: secure_configuration.CLIENT_SECRET,
//       refreshToken: secure_configuration.REFRESH_TOKEN
//     }
//   });


var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database:"project"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});


app.get('/', (req, res) => {
  res.render('login.ejs')
})

app.get('/login',(req,res)=>{
    var email = req.query.email
    var password = req.query.password
    
    var login_query = `select * from Users where Email = "${email}" and userPassword = "${password}"`

    con.query(login_query, function (err, result) {
        if (err){
            console.log(err);
            return res.send(400);
        } 
        if(result.length>0){
            result[0]["login"] = true
            if(result.UserRole=="admin"){
              return res.render('admin.ejs')
            }
            return res.render('home.ejs')
        }
        else{
            return res.send({"login":false})
        }
      });

})

app.post('/signup',(req,res)=>{
   
    var data = req.body
    console.log(data)
    var fName = data.fName ? data.fName : null
    var lName = data.lName ? data.lName : null
    var email = data.email ? data.email : null 
    var DOB = data.dob ? data.dob : null
    var userRole = data.userRole ? data.userRole : null
    var gender = data.gender ? data.gender : null
    var password = data.password ? data.password : null

    // var file = req.files.photo 
    // const filePath = path.join(__dirname, 'public', `${file.name}`)
    var photo = null

    // file.mv(filePath, err => {

    //     if (err){
    //       console.log(err)
    //     } 
    //     photo =  filePath
    // })

    var insert_user_query = `INSERT INTO  Users (LastName,FirstName,Email,DOB,Gender,UserRole,userPassword,profileImage) VALUES("${lName}","${fName}","${email}","${DOB}","${gender}","${userRole}","${password}","${photo}");`;
    console.log(insert_user_query)
     con.query(insert_user_query, function (err, result) {
        if (err){
            console.log(err);
            return res.send(400);
        } 
        console.log("1 record inserted");
      });
    return res.redirect("/")
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})